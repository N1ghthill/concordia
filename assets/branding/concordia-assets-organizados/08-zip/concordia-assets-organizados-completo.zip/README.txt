Estrutura de assets - Concórdia

01-master         -> arquivos base aprovados (fonte principal)
02-wordmark       -> wordmark final em todos os tamanhos
03-icon           -> símbolo isolado (app icon)
04-monocromatico  -> versões preto e branco
05-fundo-claro    -> versões prontas para fundo claro
06-fundo-escuro   -> versões prontas para fundo escuro
07-social         -> formatos para redes sociais
08-zip            -> pacotes compactados para envio
99-arquivo        -> histórico/versões anteriores

Observação: mantenha sempre o arquivo aprovado mais recente em 01-master.
