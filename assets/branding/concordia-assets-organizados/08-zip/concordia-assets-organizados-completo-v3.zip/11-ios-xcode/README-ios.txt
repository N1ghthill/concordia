Concordia mobile icon packs

iOS (Xcode):
1. Open ios project in Xcode.
2. Replace Assets.xcassets/AppIcon.appiconset with folder from:
   11-ios-xcode/Assets.xcassets/AppIcon.appiconset
3. Build once and verify in simulator/device.

Android:
1. Copy all folders from 12-android-res into:
   app/src/main/res/
2. If prompted, merge values/colors.xml and keep ic_launcher_background.
3. Clean/rebuild project.
